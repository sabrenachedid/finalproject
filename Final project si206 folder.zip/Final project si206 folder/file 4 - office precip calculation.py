import requests
import sqlite3
from datetime import datetime

def create_db_table(conn, cur):
    cur.execute("DROP TABLE IF EXISTS episodes")
    cur.execute('''CREATE TABLE episodes (
                    title TEXT, 
                    season INTEGER, 
                    number INTEGER, 
                    rating REAL, 
                    date TEXT,
                    precipitation REAL,
                    UNIQUE(title, season, number))''')
    conn.commit()

def insert_episode_data(conn, cur, episode_data):
    sql = ''' INSERT OR IGNORE INTO episodes(title, season, number, rating, date, precipitation)
              VALUES(?,?,?,?,?,?) '''
    cur.execute(sql, episode_data)
    conn.commit()

def fetch_precipitation_data():
    api_url = "https://cckpapi.worldbank.org/cckp/v1/cru-x0.5_timeseries_pr_timeseries_monthly_1901-2022_mean_historical_cru_ts4.07_mean/USA?_format=json"
    response = requests.get(api_url)
    if response.status_code == 200:
        data = response.json()
        return data["data"]["USA"]
    else:
        print("Failed to retrieve precipitation data from the API")
        return {}

def calculate_mean_difference(db_top, db_bottom):
    conn_top = sqlite3.connect(db_top)
    cursor_top = conn_top.cursor()
    cursor_top.execute("SELECT AVG(precipitation) FROM episodes WHERE precipitation IS NOT NULL")
    avg_top = cursor_top.fetchone()[0]

    conn_bottom = sqlite3.connect(db_bottom)
    cursor_bottom = conn_bottom.cursor()
    cursor_bottom.execute("SELECT AVG(precipitation) FROM episodes WHERE precipitation IS NOT NULL")
    avg_bottom = cursor_bottom.fetchone()[0]

    conn_top.close()
    conn_bottom.close()

    if avg_top is not None and avg_bottom is not None:
        mean_difference = avg_top - avg_bottom
        return mean_difference
    else:
        return "Cannot calculate mean difference due to insufficient data"

def main():
    conn = sqlite3.connect('office_bottom_precip.db')
    cursor = conn.cursor()

    create_db_table(conn, cursor)

    api_url = "https://api.tvmaze.com/singlesearch/shows?q=the+office&embed=episodes"
    response = requests.get(api_url)
    if response.status_code == 200:
        data = response.json()
        episodes = data['_embedded']['episodes']
        
        sorted_episodes = sorted(episodes, key=lambda x: x.get('rating', {}).get('average', 0) if x.get('rating', {}).get('average') is not None else 0)

        bottom_100_episodes = sorted_episodes[:100]

        precipitation_data = fetch_precipitation_data()

        for ep in bottom_100_episodes:
            if 'airstamp' in ep and ep['airstamp']:
                date_obj = datetime.fromisoformat(ep["airstamp"])
                episode_date = date_obj.strftime("%Y-%m")
                precipitation = precipitation_data.get(episode_date, None)
                rating = ep.get("rating", {}).get('average', None)
                episode_data = (ep["name"], ep["season"], ep["number"], rating, episode_date, precipitation)
                insert_episode_data(conn, cursor, episode_data)

    else:
        print("Failed to retrieve data from the TVMaze API")

    conn.close()

    mean_diff = calculate_mean_difference('office_top_precip.db', 'office_bottom_precip.db')

    with open('mean_difference_result.txt', 'w') as file:
        file.write(f'Mean difference in precipitation: {mean_diff}\n')

    print(f'Mean difference written to mean_difference_result.txt: {mean_diff}')

if __name__ == "__main__":
    main()
