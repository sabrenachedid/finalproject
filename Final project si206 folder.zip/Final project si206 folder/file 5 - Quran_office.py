import requests
import sqlite3
import matplotlib.pyplot as plt
from collections import Counter
from string import punctuation

def setup_db(conn):
    cur = conn.cursor()
    cur.execute('''CREATE TABLE IF NOT EXISTS episodes (season INTEGER, title TEXT)''')
    cur.execute('''CREATE TABLE IF NOT EXISTS quran_verses (verse TEXT)''')
    conn.commit()
    return cur

def fetch_quran_text():
    api_url = "https://api.alquran.cloud/v1/juz/30/en.asad"
    response = requests.get(api_url)
    if response.status_code == 200:
        return [verse['text'] for verse in response.json()['data']['ayahs']]
    else:
        print("Failed to retrieve Quran data")
        return []

def fetch_all_episodes():
    api_url = "https://api.tvmaze.com/singlesearch/shows?q=the+office&embed=episodes"
    response = requests.get(api_url)
    if response.status_code == 200:
        episodes = response.json()['_embedded']['episodes']
        return [(ep["season"], ep["name"]) for ep in episodes]
    else:
        print("Failed to retrieve episode data")
        return []

def insert_data(conn, cur, table, data):
    if table == 'quran_verses':
        cur.executemany(f'INSERT OR IGNORE INTO {table} (verse) VALUES (?)', [(item,) for item in data])
    else:
        cur.executemany(f'INSERT OR IGNORE INTO {table} VALUES (?, ?)', data)
    conn.commit()

def get_all_data(cur, table):
    cur.execute(f'SELECT * FROM {table}')
    return cur.fetchall()

def calculate_match_counts_by_season(episodes, quran_verses):
    quran_words = set(word.lower().strip(punctuation) for verse in quran_verses for word in verse.split())
    season_matches = {}

    for season, title in episodes:
        count = sum(1 for word in title.lower().split() if word.strip(punctuation) in quran_words)
        if season in season_matches:
            season_matches[season].append(count)
        else:
            season_matches[season] = [count]

    average_matches_per_season = {season: sum(counts)/len(counts) for season, counts in season_matches.items()}
    return average_matches_per_season

def main():
    conn = sqlite3.connect('office_quran_comp.db')
    cur = setup_db(conn)

    quran_verses = fetch_quran_text()
    insert_data(conn, cur, 'quran_verses', quran_verses)

    episodes = fetch_all_episodes()
    stored_episodes = get_all_data(cur, 'episodes')

    existing_episodes = {(season, title) for season, title in stored_episodes}

    count = len(stored_episodes)
    if count < 100:
        for ep in episodes:
            if (ep[0], ep[1]) not in existing_episodes:
                cur.execute("INSERT INTO episodes (season, title) VALUES (?, ?)", ep)
                existing_episodes.add((ep[0], ep[1]))
                count += 1
                if count % 25 == 0:
                    conn.commit()
                if count >= 100:
                    break

    stored_episodes = get_all_data(cur, 'episodes')
    stored_quran_verses = [verse for (verse,) in get_all_data(cur, 'quran_verses')]

    average_matches_per_season = calculate_match_counts_by_season(stored_episodes, stored_quran_verses)

    seasons = list(average_matches_per_season.keys())
    averages = list(average_matches_per_season.values())

    plt.figure(figsize=(10, 6))
    plt.bar(seasons, averages, color='skyblue')
    plt.xlabel('Season')
    plt.ylabel('Average Matched Word Count')
    plt.title('Average Matched Words Per Season in The Office with Quran')
    plt.xticks(seasons)
    plt.show()

    conn.close()

if __name__ == "__main__":
    main()