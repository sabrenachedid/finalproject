import requests
import sqlite3
from datetime import datetime

def insert_episode_data(conn, cur, episode_data):
    cur.execute('''CREATE TABLE IF NOT EXISTS episodes (
                    title TEXT, 
                    season INTEGER, 
                    number INTEGER, 
                    rating REAL, 
                    month INTEGER,
                    year INTEGER,
                    UNIQUE(title, season, number))''')
    conn.commit()

    sql = ''' INSERT OR IGNORE INTO episodes(title, season, number, rating, month, year)
              VALUES(?,?,?,?,?,?) '''
    cur.execute(sql, episode_data)
    conn.commit()

conn = sqlite3.connect('office_tepisodes.db')
cursor = conn.cursor()

api_url = "https://api.tvmaze.com/singlesearch/shows?q=the+office&embed=episodes"
response = requests.get(api_url)

if response.status_code == 200:
    data = response.json()
    episodes = data['_embedded']['episodes']
    
    sorted_episodes = sorted(episodes, key=lambda x: x.get('rating', {}).get('average', 0) if x.get('rating', {}).get('average') is not None else 0, reverse=True)

    top_100_episodes = sorted_episodes[:100]
    
    for ep in top_100_episodes:
        airstamp = ep["airstamp"]
        date_obj = datetime.fromisoformat(airstamp)
        month = date_obj.month
        year = date_obj.year

        episode_data = (ep["name"], ep["season"], ep["number"], ep.get("rating", {}).get("average", None), month, year)
        insert_episode_data(conn, cursor, episode_data)
        print(episode_data)

else:
    print("Failed to retrieve data from the API")

conn.close()


