import requests
import sqlite3
from datetime import datetime
import matplotlib.pyplot as plt

def create_db_table(conn, cur):
    cur.execute("DROP TABLE IF EXISTS episodes")
    cur.execute('''CREATE TABLE episodes (
                    title TEXT, 
                    season INTEGER, 
                    number INTEGER, 
                    rating REAL, 
                    date TEXT,
                    precipitation REAL,
                    UNIQUE(title, season, number))''')
    conn.commit()

def insert_episode_data(conn, cur, episode_data):
    sql = ''' INSERT OR IGNORE INTO episodes(title, season, number, rating, date, precipitation)
              VALUES(?,?,?,?,?,?) '''
    cur.execute(sql, episode_data)
    conn.commit()

def fetch_precipitation_data():
    api_url = "https://cckpapi.worldbank.org/cckp/v1/cru-x0.5_timeseries_pr_timeseries_monthly_1901-2022_mean_historical_cru_ts4.07_mean/USA?_format=json"
    response = requests.get(api_url)
    if response.status_code == 200:
        data = response.json()
        return data["data"]["USA"]
    else:
        print("Failed to retrieve precipitation data from the API")
        return {}

def main():
    conn = sqlite3.connect('office_top_precip.db')
    cursor = conn.cursor()

    create_db_table(conn, cursor)

    api_url = "https://api.tvmaze.com/singlesearch/shows?q=the+office&embed=episodes"
    response = requests.get(api_url)

    if response.status_code == 200:
        data = response.json()
        episodes = data['_embedded']['episodes']

        top_episodes = sorted(episodes, key=lambda x: x.get('rating', {}).get('average', 0), reverse=True)[:100]

        precipitation_data = fetch_precipitation_data()

        count = 0
        for ep in top_episodes:
            if count < 100: 
                if 'airstamp' in ep and ep['airstamp']:
                    date_obj = datetime.fromisoformat(ep["airstamp"])
                    episode_date = date_obj.strftime("%Y-%m")
                    precipitation = precipitation_data.get(episode_date, None)
                    rating = ep.get("rating", {}).get('average', None)
                    episode_data = (ep["name"], ep["season"], ep["number"], rating, episode_date, precipitation)
                    insert_episode_data(conn, cursor, episode_data)
                    count += 1
                    if count % 25 == 0: 
                        conn.commit()
            else:
                break  

    cursor.execute("SELECT * FROM episodes")
    episodes = cursor.fetchall()

    conn.close()

    dates = []
    precipitation_values = []

    for ep in episodes:
        episode_date = datetime.strptime(ep[4], "%Y-%m")
        dates.append(episode_date)
        precipitation_values.append(ep[5] if ep[5] is not None else 0)

    plt.figure(figsize=(10, 6))
    plt.scatter(dates, precipitation_values, color='blue', alpha=0.7)
    plt.title('Top 100 Office Episodes and Precipitation')
    plt.xlabel('Airdate')
    plt.ylabel('Precipitation')
    plt.grid(True)
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()